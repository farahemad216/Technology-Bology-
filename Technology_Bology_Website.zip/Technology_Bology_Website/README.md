# Technology Bology Website

A responsive four-page HTML website for a web development coursework assignment.

## Files
- `index.html` — Home
- `about.html` — About
- `products.html` — Products (includes Earbuds, Keyboard and Mouse, Logitech Laptop, and Wireless Potato)
- `contact.html` — Contact form with native HTML validation
- `style.css` — Shared styling
- `script.js` — Contact form demo behavior

## Preview locally
Open `index.html` in a browser.

## Validate HTML
Upload or paste each HTML page into https://validator.w3.org/ and fix any reported errors. Take a screenshot of the actual validation result for submission. Do not use a simulated report.

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload all six website files to the repository root.
3. Open **Settings → Pages**.
4. Under build and deployment, choose **Deploy from a branch**, select `main` and `/(root)`, then save.
5. Wait for GitHub Pages to publish the site and copy the provided URL for submission.

Prices are sample values for coursework and can be edited in `products.html`.
