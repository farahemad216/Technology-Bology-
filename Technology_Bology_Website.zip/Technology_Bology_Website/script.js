document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("contact-form");
  if (!form) return;

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    const message = document.getElementById("form-message");

    if (!form.checkValidity()) {
      form.reportValidity();
      message.textContent = "";
      return;
    }

    message.textContent = "Thank you! Your form entries passed validation. This demo does not send messages to a server.";
    form.reset();
  });
});
